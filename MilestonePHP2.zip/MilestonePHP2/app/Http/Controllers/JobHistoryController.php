<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Business\JobHistoryBusinessDataSerivce;

class JobHistoryController extends Controller
{
        public function readAllJobHistory(){
        
        $jobHistoryDataSerivce = new JobHistoryBusinessDataSerivce();
        $data = $jobHistoryDataSerivce->read();
        
        $JobHistoryModels = Array();
        while ($row = mysqli_fetch_assoc($data)) {
            array_push($JobHistoryModels, $row);
        }
            return view('jobHistory')->with('JobHistoryModels',$JobHistoryModels);
            
        }
        
        
        public function deleteHistory(Request $request){
            
            $JobService = new JobHistoryBusinessDataSerivce();
            //$job = new JobHistoryModel();
            
            $jobID = $request->input('jobID');
            
            $isDeleted = $JobService->delete($jobID);
            
            if($isDeleted){
                $jobHistoryDataSerivce = new JobHistoryBusinessDataSerivce();
                $data = $jobHistoryDataSerivce->read();
                
                $JobHistoryModels = Array();
                while ($row = mysqli_fetch_assoc($data)) {
                    array_push($JobHistoryModels, $row);
                }
                return view('jobHistory')->with('JobHistoryModels',$JobHistoryModels);
                
            }
            else{
                echo "unable to delete . Check php code";
            }
            
        }
}
